<?php 


    session_start();
    session_unset();
    session_destroy();

    header("location: http://rmsproject.free.nf/admin-panel/admins/login-admins.php");