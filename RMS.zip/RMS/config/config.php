<?php

    define("HOST", "sql306.infinityfree.com");
    define("DBNAME", "if0_36614607_restoran");
    define("USER", "if0_36614607");
    define("PASS", "76863880Hk");